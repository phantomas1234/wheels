function loaded_object = load_mat( the_filename )
	loaded_object = load( the_filename);

