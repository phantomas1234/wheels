
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.1'
version = '1.8.1'
full_version = '1.8.1'
git_revision = '46bc2fc3041dee0ec274d6a29492b95e6fdbbfab'
release = True

if not release:
    version = full_version
