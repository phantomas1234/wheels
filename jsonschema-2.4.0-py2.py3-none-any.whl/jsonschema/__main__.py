from jsonschema.cli import main
main()
