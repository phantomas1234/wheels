function the_string = cell_to_string( the_cell_array )
	the_string = sprintf( '%s\t', the_cell_array{:} );

