
"""
TODO: add a docstring.

"""

class Delimiters(object):

    def first(self):
        return "It worked the first time."

    def second(self):
        return "And it worked the second time."

    def third(self):
        return "Then, surprisingly, it worked the third time."
