function the_container = create_container(the_keys, the_values)
    the_container = containers.Map(the_keys, the_values);
