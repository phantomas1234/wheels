function [] = save_from_python( the_file, the_model )
	save the_file the_model;	

